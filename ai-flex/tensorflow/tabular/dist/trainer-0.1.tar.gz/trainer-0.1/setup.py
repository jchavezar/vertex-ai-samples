from setuptools import setup

setup(
    name='trainer',
    version='0.1',
    include_package_data=True,
    description='My training application.'
)
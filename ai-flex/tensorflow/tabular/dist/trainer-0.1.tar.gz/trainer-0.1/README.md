![](../../images/aip-flex.png)

## Getting Started

All the steps are modular/flexible so the order is not important, variables.py is the file for setting the values.

## For custom containers
### Build & Push Images
```sh
docker build -t us-central1-docker.pkg.dev/vtxdemos/custom-trains/tf-preprocess_cpu:1.0 trainer/.
docker push us-central1-docker.pkg.dev/vtxdemos/custom-trains/tf-preprocess_cpu:1.0
```

## For pre-built containers
### Build Eggs or Python Distribution Packages
```sh
docker build -t us-central1-docker.pkg.dev/vtxdemos/custom-trains/tf-preprocess_cpu:1.0 trainer/.
docker push us-central1-docker.pkg.dev/vtxdemos/custom-trains/tf-preprocess_cpu:1.0
```